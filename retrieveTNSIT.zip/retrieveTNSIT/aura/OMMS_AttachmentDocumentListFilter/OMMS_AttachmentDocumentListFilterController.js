({
    doInit : function(component,event,helper){
        
        //Code for getting page reference
        var myPageRef = component.get("v.pageReference");
        if(myPageRef != null){
            var recordId = myPageRef && myPageRef.state ? myPageRef.state.c__recordId : null;
            var showSpinner = myPageRef && myPageRef.state ? myPageRef.state.c__showSpinner : null;
            var isFromCase = myPageRef && myPageRef.state ? myPageRef.state.c__isFromCase : null;
            component.set("v.recordId", recordId);
            component.set("v.showSpinner", showSpinner);
            component.set("v.isFromCase", isFromCase);
        }
        var recordId = component.get("v.recordId");
        var showSpinner = component.get("v.showSpinner");
        var isFromCase = component.get("v.isFromCase");
        
        if(component.get("v.isCommunity")){
            component.set("v.pageSize", 5);
        }
        
        // call helper methods to fetch data from apex
        helper.getColumn(component);
        helper.getMedicaidNPIId(component, recordId, helper);
        helper.getDocumentType(component, isFromCase, recordId,  helper);
        helper.getAttachmentDetails(component, isFromCase, recordId, helper);
        
    },
    
    //For file download 
    startFileDownload : function(component, event, helper) {   
        var selectedElement = event.target;
        var refId = selectedElement.getAttribute('data-refId');
        var docName = selectedElement.getAttribute('data-fileName');
        
        var action = component.get('c.downloadAttachment');
        action.setParams({
            'recordId' : component.get('v.recordId'),
            'storageRefId' : refId,
            'fileName' : docName
        });
        action.setCallback(this, function(response){
            
            var state = response.getState();
             if (state === "SUCCESS") {
            var result = response.getReturnValue();
            
            var downloadLink = document.createElement("a");
            downloadLink.href = result;
            downloadLink.download = docName;
            
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
            }
            
            else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                     if (errors[0] && errors[0].message) {
                    console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                     }
                }
            }
            
        });
        $A.enqueueAction(action);
    },
    //end
    
    onNext : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber+1);
        helper.buildData(component, helper);
    },
    
    onPrev : function(component, event, helper) {        
        var pageNumber = component.get("v.currentPageNumber");
        component.set("v.currentPageNumber", pageNumber-1);
        helper.buildData(component, helper);
    },
    
    onFirst : function(component, event, helper) {        
        component.set("v.currentPageNumber", 1);
        helper.buildData(component, helper);
    },
    
    onLast : function(component, event, helper) {        
        component.set("v.currentPageNumber", component.get("v.totalPages"));
        helper.buildData(component, helper);
    },
    
    
    /*
     * Method to handle sort action
     */
    handleSort : function(component,event,helper){
        var selectedElement = event.currentTarget;
        var sortBy = selectedElement.getAttribute('data-sortBy');
        var sortDirection = selectedElement.getAttribute('data-sortDirection');
        component.set("v.sortBy",sortBy);
        component.set("v.sortDirection",sortDirection);
        event.currentTarget.setAttribute('data-sortDirection', sortDirection == 'asc' ? 'desc' : 'asc');
        helper.sortData(component,sortBy,sortDirection);
    },
    
    /*
     * Method to filter table data based on Document Type selection
     * with Pagination
     */
    filter: function(component, event, helper) {
        var allAttachmentdata = component.get("v.data"),
            term = component.find("docType").get("v.value"),
            results = allAttachmentdata, regex;
        component.set("v.selectedDocType", term);
        if(term === 'All'){
            component.set('v.isAttachmentNotAvailable', false);
            component.set("v.attachmentData", allAttachmentdata);
            component.set("v.currentPageNumber", 1);
            component.set("v.paginationList", null);
            helper.buildData(component, helper);
            
        }else{
            try {
                //regex = new RegExp("^" + term + "$", 'i');  // case insensitive
                regex = new RegExp("^" + term + "$");// case sensitive
                // filter checks each row, constructs new array where function returns true
                results = allAttachmentdata.filter(row=>regex.test(row.docType));
                if (results === '' ||  results === null || results ===  undefined || results.length === 0) 
                { 
                    console.log('inside result null');
                    component.set('v.isAttachmentNotAvailable', true);
                    component.set("v.paginationList", null);
                    component.set("v.attachmentData", null);
                }
                if(results != null && results.length > 0){
                    console.log('inside result not null');
                    component.set('v.isAttachmentNotAvailable', false);
                    component.set("v.attachmentData", results);
                    component.set("v.currentPageNumber", 1);
                    component.set("v.paginationList", null);
                    helper.buildData(component, helper);
                }
            } catch(Exception) {
                return "Pattern matches must be a valid regex value";
            }
            
        }
    },
    
})