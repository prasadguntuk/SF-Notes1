({
    /*
     * Method to display table column
     */
    getColumn : function(component) { 
        
        component.set("v.attachmentColumns",[
            {
                label : 'Attachment Name',
                fieldName : 'documentName',
                type : 'url',
                typeAttributes: {label: { fieldName: 'documentName' },
                                 target: '_blank'},
                sortable : true,
                cellAttributes: { alignment: 'left' }
            },
            
            {
                label : 'Document Type',
                fieldName : 'docType',
                type : 'text',
                sortable : true,
                cellAttributes: { alignment: 'left' }
            },
            { 
                label: 'Date',
                fieldName: 'documentDateNew', 
                type: 'date', 
                typeAttributes: {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true
                },
                sortable: true,
                cellAttributes: { alignment: 'left' }
            }
        ]);
        
    },
    
    
    /*
     * Method to get Document Type list
     * wrt the sobject on which the component is loaded.
     */
    getDocumentType : function(component, isFromCase, recordId, helper) {
        var getDocumentTypeAction = [];
        if(isFromCase === 'true'){
            getDocumentTypeAction = component.get('c.getDocumentTypesForCase'); 
            // set the parameters to method  
            getDocumentTypeAction.setParams({
                'caseRecordId' : recordId
            });
        }else{
            getDocumentTypeAction = component.get('c.getDocumentTypes');
            // set the parameters to method  
            getDocumentTypeAction.setParams({
                'recordId' : recordId
            });
        }
        getDocumentTypeAction.setCallback(this, $A.getCallback(function (response) {
            var docTypeResList=[];
            var state = response.getState();             
            if (state === "SUCCESS") {                   
                var arr = response.getReturnValue() ;
                if(arr != null){
                    docTypeResList.push({ value: 'All', label: 'All' });
                    arr.forEach(function(element) {
                        docTypeResList.push({ value: element.value, label: element.label });
                    });
                    component.set("v.docType", 'All');
                    component.set("v.docTypeOptions", docTypeResList);		
                }
            }  else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                     if (errors[0] && errors[0].message) {
                    console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                     }
                }
            }
        }));   
        $A.enqueueAction(getDocumentTypeAction);
    },
    
    /*
     * Method to fetch the attachment
     * wrt the sobject on which the component is loaded.
     */
    getAttachmentDetails : function(component, isFromCase, recordId, helper){
        
        var getAttachmentAction = [];
        if(isFromCase === 'true'){
            getAttachmentAction = component.get('c.getAttachmentsForCase');
            // set the parameters to method  
            getAttachmentAction.setParams({
                'caseRecordId' : recordId
            });
        }else{
            getAttachmentAction = component.get('c.getAttachments');  
            // set the parameters to method  
            getAttachmentAction.setParams({
                'recordId' : recordId
            });
        }
        getAttachmentAction.setCallback(this, function(response){
            var state = response.getState();            
            if (state === "SUCCESS") {
                var arr = response.getReturnValue();
                component.set("v.showSpinner", false);
                component.set('v.isAttachmentNotAvailable', false);
                component.set("v.attachmentData", response.getReturnValue());
                component.set("v.data", response.getReturnValue());
                component.set("v.currentPageNumber", 1);
                helper.buildData(component, helper);
            }
            
             else if (state === "ERROR") {
                component.set('v.PaginationList', null);
                var errors = response.getError();
                if (errors) {
                     if (errors[0] && errors[0].message) {
                    console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                     }
                }
            }
            
        });       
        $A.enqueueAction(getAttachmentAction);
    },
    
    
    
    /*
     * Method to sort table column data
     * based on field selection.
     */
    sortData : function(component, fieldName, sortDirection){
        var sortData = component.get("v.attachmentData");
        //function to return the value stored in the field
        var key = function(a) { return a[fieldName]; }
        var reverse = sortDirection == 'asc' ? 1: -1;
        if(fieldName == 'documentDateNew'){ // to handel number/currency type fields 
            sortData.sort(function(a,b){
                var a = key(a) ? key(a) : '';
                var b = key(b) ? key(b) : '';
                a = Date.parse(a);
                b = Date.parse(b);
                return reverse * ((a>b) - (b>a));
            });
            
        }
        else{ // to handel text type fields
            sortData.sort(function(a,b){ 
                var a = key(a) ? key(a).toLowerCase() : '';//To handle null values , uppercase records during sorting
                var b = key(b) ? key(b).toLowerCase() : '';
                return reverse * ((a>b) - (b>a));
            });    
            
        }
        
        component.set("v.attachmentData", sortData);
        var datasort = [];
        var allData = component.get("v.attachmentData");
        component.set("v.totalPages", Math.ceil(allData.length/component.get("v.pageSize")));
        component.set("v.totalRecords", allData.length);
        
        var totalRecords = allData.length;
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var x = (pageNumber-1)*pageSize;
        var end = pageSize * pageNumber;
        var recordend = totalRecords >= end ? end : totalRecords;
        
        component.set("v.RecordStart", x + 1);
        component.set("v.RecordEnd", recordend);
        
        //creating data-table data
        for(; x<=(pageNumber)*pageSize-1; x++){
            if(allData[x]){
                datasort.push(allData[x]);
            }
        }
        component.set("v.currentPageSize", datasort.length);
        component.set("v.paginationList", datasort);
        
    },
    
    /*
     * Method to get Medicaid and NPI Id for Member/Provider/Facility
     * wrt the sobject on which the component is loaded.
     */
    getMedicaidNPIId : function(component, helper) {
        
        var getMedicaidNpiIdAction = component.get('c.getMemberProviderDetails');     
        getMedicaidNpiIdAction.setParams({ 
            "recordId": component.get('v.recordId')			
        });       
        getMedicaidNpiIdAction.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();             
            if (state === "SUCCESS") {                   
                var response = response.getReturnValue() ;
                if(response != null){
                    if(response.developerName === 'PersonAccount'){
                        component.set("v.medicaidOrNpi", 'Medicaid ID');
                        component.set("v.medicaidOrNpiId", response.medicaidId);
                        component.set("v.caseId", response.caseId);
                    }
                    if(response.developerName === 'Atypical_Provider' || response.developerName === 'ommsCrmAtypical_Organization' ){
                        component.set("v.medicaidOrNpi", 'API');
                        component.set("v.medicaidOrNpiId", response.apiID);
                        component.set("v.caseId", response.caseId);
                    }
                    if(response.developerName === 'MCO'){
                        component.set("v.medicaidOrNpi", 'TaxId');
                        component.set("v.medicaidOrNpiId", response.taxID);
                        component.set("v.caseId", response.caseId);
                    }
                    if(response.developerName != 'PersonAccount' && response.developerName != 'Atypical_Provider' && response.developerName != 'ommsCrmAtypical_Organization' && response.developerName != 'MCO'){
                        component.set("v.medicaidOrNpi", 'NPI');
                        component.set("v.medicaidOrNpiId", response.npiID);
                        component.set("v.caseId", response.caseId);
                    }
                    if(response.developerName === 'Provider'){
                        component.set("v.medicaidOrNpi", 'NPI');
                        component.set("v.medicaidOrNpiId", response.provNpiID);
                        component.set("v.caseId", response.caseId);
                    }
                    
                }
            }  else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                     if (errors[0] && errors[0].message) {
                    console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                     }
                }
            }
        }));   
        $A.enqueueAction(getMedicaidNpiIdAction);
        
    },
    
    /*
     * this function will build table data
     * based on current page selection.
     */
    buildData : function(component, helper) {
        var getBuilDdata = [];
        var allData = component.get("v.attachmentData");
        component.set("v.totalPages", Math.ceil(allData.length/component.get("v.pageSize")));
        component.set("v.totalRecords", allData.length);
        
        var totalRecords = allData.length;
        var pageNumber = component.get("v.currentPageNumber");
        var pageSize = component.get("v.pageSize");
        var x = (pageNumber-1)*pageSize;
        var end = pageSize * pageNumber;
        var recordend = totalRecords >= end ? end : totalRecords;
        
        component.set("v.RecordStart", x + 1);
        component.set("v.RecordEnd", recordend);
        
        //creating data-table data
        for(; x<=(pageNumber)*pageSize-1; x++){
            if(allData[x]){
                getBuilDdata.push(allData[x]);
            }
        }
        component.set("v.currentPageSize", getBuilDdata.length);
        component.set("v.paginationList", getBuilDdata);
        
    },
    
})