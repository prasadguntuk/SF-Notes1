({
    doInit : function(component, event, helper) {
        //fetch current user profile
        helper.getUserDetails(component);
        /*fetch the attachment wrt the sobject on which the component is loaded*/
        helper.getAttachmentRelatedList(component);
        /*Fetch Medicaid and Npi Id details*/
        helper.getMedicaidNPIId(component);
        
        //Code for Document Type list start        
        var action = component.get('c.getDocumentTypes');        
        action.setParams({ 
            "recordId": component.get('v.recordId')            
        });         
        action.setCallback(this, $A.getCallback(function (response) {
            var docTypeResList=[];            
            var state = response.getState();             
            if (state === "SUCCESS") {                   
                var arr = response.getReturnValue() ;  
                if(arr != null){
                    arr.forEach(function(element) {
                        
                        docTypeResList.push({ value: element.value, label: element.label });
                        
                    });                    	
                }else{
                    docTypeResList.push({ value:'', label: '-Select-' }); 
                }
                component.set("v.docTypeOptions", docTypeResList);
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.log(errors);
            }
        }));   
        $A.enqueueAction(action); 
        
        //Code for Document Type list End
      	
        // Code for directionOptions list start 
        var actionDirection = component.get('c.getDirections');       
        var defaultDirection='';
        actionDirection.setCallback(this, $A.getCallback(function (response) {
            var directionList=[];
            var state = response.getState();        
            if (state === "SUCCESS") {                         
                
                var arr = response.getReturnValue() ;                 
                arr.forEach(function(element) {
                    directionList.push({ value: element.value, label: element.label });
                });
                component.set("v.directionOptions", directionList); 
                component.set("v.defaultDirection", directionList[0].value);
            } else if (state === "ERROR") {
                var errors = response.getError();
                console.log(errors);
            }
        }));   
        $A.enqueueAction(actionDirection);
       
        ////Code for directionOptions list End
    },
    /*For Opening Model*/ 
    openModel: function(component, event, helper) {
        try{
            var now = new Date();
            component.set("v.isOpen", true);
            component.set("v.attachmentDateTime", now.toISOString() );
            
            var docTypeOptions= component.get("v.docTypeOptions");
            if(docTypeOptions != null)
            {                
                var defaultDocumentTypeOption='';
                var docTypeOptionsList = docTypeOptions;
                
                for (var index = 0; index < docTypeOptionsList.length; index++) { 
                    if(component.get("v.docTypeForDesignAttribute") != null && component.get("v.docTypeForDesignAttribute")!= '' )
                    {
                        if((docTypeOptionsList[index].label).toLowerCase() === component.get("v.docTypeForDesignAttribute").toLowerCase().trim() )
                        {
                            defaultDocumentTypeOption= docTypeOptionsList[index].value;
                        } 
                    } 
                }                
                
                if( defaultDocumentTypeOption != '')
                {
                    if(defaultDocumentTypeOption.toLowerCase().includes('claim') )
                    {
                        component.set("v.defaultDocTypeOption", defaultDocumentTypeOption);
                        $A.util.removeClass(component.find("claimDiv"), "slds-hide");
                        $A.util.addClass(component.find("claimDiv"), "slds-show");   
                    }else{
                        component.set("v.defaultDocTypeOption", defaultDocumentTypeOption);
                        $A.util.removeClass(component.find("claimDiv"), "slds-show");
                        $A.util.addClass(component.find("claimDiv"),"slds-hide" );
                        
                    }
                }  else {
                    component.set("v.defaultDocTypeOption", defaultDocumentTypeOption);
                }  
                
            }    
            window.setTimeout(
               $A.getCallback(function(){
                   component.find("modalClose").focus();
               }),1				
           );            
        }
        catch(error){
            console.log('***error' + error);    
        }
        
    }, 
  /*For closing Model*/    
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "False"  
        component.set("v.isOpen", false);
        component.set("v.fileName","");
        component.set("v.fileErrorMesssage","");
        component.find("claimId").set("v.value","");
        // $A.get('e.force:refreshView').fire();
        document.getElementById("docUploadButton").focus(); 
    },
     /*For Handling Change event on Document Type*/ 
    handleChange: function(component, event, helper) {        
        
        var selectedDocumentType = event.getParam("value");        
        if(selectedDocumentType.toLowerCase().includes('claim'))    
        {
            $A.util.removeClass(component.find("claimDiv"), "slds-hide");
            $A.util.addClass(component.find("claimDiv"), "slds-show");            
            
            component.find("claimId").set("v.value","");
            var documentType   =component.find("documentType").get("v.value");
            var documentTypeinputCmp = component.find("documentType");   
            
            (documentType === '' ||  documentType === null || documentType ===  undefined) ? documentTypeinputCmp.setCustomValidity("Documnent Type is required"):documentTypeinputCmp.setCustomValidity("");       
            documentTypeinputCmp.reportValidity();            
            
        }else
        {     
            $A.util.removeClass(component.find("claimDiv"), "slds-show");
            $A.util.addClass(component.find("claimDiv"),"slds-hide" );
            
            component.find("claimId").set("v.value","");           
            var documentType   =component.find("documentType").get("v.value");
            var documentTypeinputCmp = component.find("documentType");             
            (documentType === '' ||  documentType === null || documentType ===  undefined) ? documentTypeinputCmp.setCustomValidity("Documnent Type is required"):documentTypeinputCmp.setCustomValidity("");       
            documentTypeinputCmp.reportValidity();         
            
            
        }
        
        
    },
    
  /*For  Save File Upload*/  
    save : function(component, event, helper) {        
        
        var attachmentDateTime = component.find("attachmentDateTime").get("v.value");
        var attachmentName   = component.find("attachmentName").get("v.value");
        var documentType   =component.find("documentType").get("v.value");
        var claimId   =component.find("claimId").get("v.value");
        var direction =component.find("direction").get("v.value");        
        
        var  validAttachmentDateTime = false;       
        var  validAttachmentName = false;
        var  validDocumentType = false;
        var  validClaimId = false;
        var  validDirection= false;
        
        var attachmentDateTimeinputCmp = component.find("attachmentDateTime");       
        var attachmentNameinputCmp = component.find("attachmentName"); 
        var documentTypeinputCmp = component.find("documentType"); 
        var claimIdinputCmp = component.find("claimId"); 
        var directioninputCmp = component.find("direction"); 
        if (attachmentDateTime === '' ||  attachmentDateTime === null|| attachmentDateTime ===  undefined) 
        { 
            validAttachmentDateTime=false;
            attachmentDateTimeinputCmp.setCustomValidity("Date and Time is required.");
            attachmentDateTimeinputCmp.reportValidity();
        }else{
            var currentDate = new Date();
            if(Date.parse(attachmentDateTime) > currentDate.getTime()){                
                validAttachmentDateTime=false;
                attachmentDateTimeinputCmp.setCustomValidity("Please select today's date or past date. Future date is not allowed.");
                attachmentDateTimeinputCmp.reportValidity();
            }else{
                validAttachmentDateTime=true;
                attachmentDateTimeinputCmp.setCustomValidity("");
                attachmentDateTimeinputCmp.reportValidity();
            }           
            
        }     
        
        if(attachmentName === '' ||  attachmentName === null|| attachmentName ===  undefined) 
        { 
            validAttachmentName = false;
            attachmentNameinputCmp.setCustomValidity("Attachment Name is required.");
            attachmentNameinputCmp.reportValidity();        
        }
        else{
            validAttachmentName = true;
            attachmentNameinputCmp.setCustomValidity(""); 
            attachmentNameinputCmp.reportValidity();        
        }
        
        if(documentType === '' ||  documentType === null || documentType ===  undefined)
        {  
            validDocumentType = false;
            documentTypeinputCmp.setCustomValidity("Documnent Type is required.");
            documentTypeinputCmp.reportValidity(); 
        }else{ 
            
            validDocumentType = true;
            documentTypeinputCmp.setCustomValidity("");       
            documentTypeinputCmp.reportValidity();   
        }
        
        if((validDocumentType) && (documentType.toLowerCase().includes('claim')) && (claimId === '' || claimId === undefined || claimId === null) ) 
        { 
            validClaimId = false;
            claimIdinputCmp.setCustomValidity("Enter 18 character Claim ID.");
            claimIdinputCmp.reportValidity();
        }
        else {
            if(claimId.length != 18)
            {
                validClaimId = false;
                claimIdinputCmp.setCustomValidity("Enter 18 character Claim ID.");
                claimIdinputCmp.reportValidity();
            }else{
                validClaimId = true;
                claimIdinputCmp.setCustomValidity("");          
                claimIdinputCmp.reportValidity();              
            }
        }
        if(direction === '' ||  direction === null || direction ===  undefined)
        {  
            validDirection = false;
            directioninputCmp.setCustomValidity("Direction is required");
            directioninputCmp.reportValidity(); 
        }else{ 
            
            validDirection = true;
            directioninputCmp.setCustomValidity("");       
            directioninputCmp.reportValidity();   
        }          
        
        if ( validAttachmentDateTime  && validAttachmentName && validDocumentType && validDirection && (documentType.toLowerCase().includes('claim')))
        {
            
            if(validClaimId)
            {
                
                if (component.find("fileuploader").get("v.files") != null) { 
                    if(component.find("fileuploader").get("v.files")[0]['name'].length <= 80 )
                    {
                        
                        helper.uploadHelper(component, event,helper);
                        
                    }else{
                        component.set("v.fileName", fileName);
                        component.set("v.fileErrorMesssage", "File Name should not excced 80 character with extension.");
                        return;	
                    }
                    
                } else {
                    
                    component.set("v.fileErrorMesssage", "Please select file to upload.");                      
                    return;
                }  
            }else{
                validClaimId = false;
                claimIdinputCmp.setCustomValidity("Enter 18 character Claim Id.");
                claimIdinputCmp.reportValidity();
                return;
            }
            
        }else if ( validAttachmentDateTime  && validAttachmentName && validDocumentType && validDirection && (!(documentType.toLowerCase().includes('claim'))))
        {
            
            if (component.find("fileuploader").get("v.files") != null) { 
                if(component.find("fileuploader").get("v.files")[0]['name'].length <= 80 )
                {
                    
                    helper.uploadHelper(component, event,helper);
                    
                }else{
                    component.set("v.fileName", fileName);
                    component.set("v.fileErrorMesssage", "File Name should not excced 80 character with extension.");
                    return;	
                }
                
            } else {
                
                component.set("v.fileErrorMesssage", "Please select file to upload.");                      
                return;
            }  
            
        }else{
            return;
            
        }      
        
    },
    /*For Uploaded file Name Validation*/
    handleFilesChange: function(component, event, helper) {
        var fileName = '';
        
        if (event.getSource().get("v.files").length > 0) {
            
            fileName = event.getSource().get("v.files")[0]['name'];
            if(fileName.length >80 )
            {
                component.set("v.fileName", fileName);
                component.set("v.fileErrorMesssage", "File Name should not excced 80 character with extension.");
                return;			
            }
        }
        component.set("v.fileName", fileName);
        component.set("v.fileErrorMesssage", ""); 
    },
     /*For Date Validation*/
    dateTimeUpdated: function(component,event,helper){
        var target = event.getSource();
        
        if(!$A.util.isUndefinedOrNull(target)) {
            var attachmentDateTimeinputCmp = component.find("attachmentDateTime"); 
            var inputDateTimeValue = target.get("v.value");
            var currentDate = new Date();
            if(Date.parse(inputDateTimeValue) > currentDate.getTime()){               
                attachmentDateTimeinputCmp.setCustomValidity("Please select today's date or past date. Future date is not allowed.");
                attachmentDateTimeinputCmp.reportValidity();
            }else{
                attachmentDateTimeinputCmp.setCustomValidity("");
                attachmentDateTimeinputCmp.reportValidity();
            }
        }
    },
    /*For File Download*/
    startFileDownload : function(component, event, helper) {
        
        var selectedElement = event.target;
        var refId = selectedElement.getAttribute('data-refId');
        var docName = selectedElement.getAttribute('data-fileName');
        
        var action = component.get('c.downloadAttachment');
        action.setParams({
            'caseRecordId' : component.get('v.recordId'),
            'storageRefId' : refId,
            'fileName' : docName
        });
        action.setCallback(this, function(response){
            var result = response.getReturnValue();
            
            var downloadLink = document.createElement("a");
            downloadLink.href = result;
            downloadLink.download = docName;
            
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
           
        });
        $A.enqueueAction(action);
        
    },
    /*File Download end*/
    
    /*
     * Method to get attached document List data table grid subtab
     * after click on View All
     */
    handleViewAllClick : function(component, event, helper){
        
        var recordId = component.get("v.recordId");
        helper.getAttachmentRelatedList(component);
        var medicaidOrNpiId = component.get("v.medicaidOrNpiId");
        
        if(component.get("v.isCommunity")){
            component.set("v.showSpinner", true);
            $A.createComponent(
                "c:OMMS_AttachmentDocumentListFilter",{
                    "recordId":recordId,
                    "isFromCase":"true",
                    "showSpinner": "true",
                    "isCommunity": true,
                    "aura:id": "inpId"
                },
                function(newcomponent){
                    if (component.isValid()) {
                        var body = component.get("v.body");
                        body.push(newcomponent);
                        component.set("v.body", body);
                        component.set("v.isOpenNew", true);
                        component.set("v.showSpinner", false);
                         window.setTimeout(
               				$A.getCallback(function(){
                   			component.find("modalCloseNew").focus();
               }),1				
           ); 
                    }
                }            
            );
            
        }else{
            var workspaceAPI = component.find("workspace");
            workspaceAPI.getEnclosingTabId().then(function(enclosingTabId) {
                workspaceAPI.openSubtab({
                    parentTabId: enclosingTabId,
                    pageReference: {
                        "type": "standard__component",
                        "attributes": {
                            "componentName": "c__OMMS_AttachmentDocumentListFilter"
                        },
                        "state": {
                            "uid": "1",
                            "c__recordId" : recordId,
                            "c__showSpinner" : 'true',
                            "c__isFromCase" : 'true'
                        }
                        
                    }
                }).then(function(subtabId) {
                    
                    workspaceAPI.setTabLabel({
                        tabId: subtabId,
                        label: medicaidOrNpiId
                    });
                    workspaceAPI.setTabIcon({
                        tabId: subtabId,
                        icon: "standard:document",
                        iconAlt: "Document List"
                    });
                    
                }).catch(function(error) {
                    console.log("error");
                });
            });
        }
    },
    /*View All end*/    
    
    closeModelNew: function(component, event, helper) {
      component.set("v.isOpenNew", false);
       component.find("inpId").destroy();
       document.getElementById("docUploadButton").focus(); 
   },
})