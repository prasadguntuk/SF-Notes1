({
    doInit : function(component, event, helper) {
        //fetch current user profile
        helper.getUserDetails(component);
        /*fetch the attachment wrt the sobject on which the component is loaded*/
        helper.getAttachmentRelatedList(component);
        /*Fetch Medicaid and Npi Id details*/
        helper.getMedicaidNPIId(component);
        
        //Code for Document Type list start 
        var action = component.get('c.getDocumentTypes');     
        
        action.setParams({ 
            "recordId": component.get('v.recordId')			
        });       
        
        action.setCallback(this, $A.getCallback(function (response) {
            var docTypeResList=[];
            var state = response.getState();             
            if (state === "SUCCESS") {                   
                var arr = response.getReturnValue(); 
                if(arr){
                    arr.forEach(function(element) {
                    docTypeResList.push({ value: element.value, label: element.label });
                });
                component.set("v.docTypeOptions", docTypeResList);
                }
                	
                
            }  else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                     if (errors[0] && errors[0].message) {
                    console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                     }
                }
            }
        }));   
        $A.enqueueAction(action);
        
        //Code for Document Type list End
        
        ////Code for directionOptions list start 
        var actionDirection = component.get('c.getDirections');       
        var defaultDirection='';
        actionDirection.setCallback(this, $A.getCallback(function (response) {
            var directionList=[];
            var state = response.getState();        
            if (state === "SUCCESS") {                         
                
                var arr = response.getReturnValue() ;  
                if(arr != null){
                 arr.forEach(function(element) {
                    directionList.push({ value: element.value, label: element.label });
                });
                component.set("v.directionOptions", directionList); 
                component.set("v.defaultDirection", directionList[0].value);   
                }
                
            }  else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                     if (errors[0] && errors[0].message) {
                    console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                     }
                }
            }
        }));   
        $A.enqueueAction(actionDirection);
  
    },
 /*  Open Model Method */
    openModel: function(component, event, helper) {
        try{
          //  $("main :focusable").addClass("disabled").attr("tabindex", -1);
            var now = new Date();
            component.set("v.isOpen", true);
            component.set("v.attachmentDateTime", now.toISOString() );    
            window.setTimeout(
               $A.getCallback(function(){
                   component.find("modalClose").focus();
               }),1				
           );
        }
        
        catch(error){
            console.log('***error' + error);    
        }
        
    },
    /*  closeModel Method */
    closeModel: function(component, event, helper) {
        // for Hide/Close Model,set the "isOpen" attribute to "False"  
        component.set("v.isOpen", false);
        component.set("v.fileName","");
        component.set("v.fileErrorMesssage","");
        component.find("claimId").set("v.value","");
        $A.get('e.force:refreshView').fire();
        document.getElementById("docUploadButton").focus(); 
    },
    /*   Method to handle Onchange event on Document Type Drop down*/
    handleChange: function(component, event, helper) {     
        var doctp = event.getParam("value");        
        if(doctp.toLowerCase().includes('claim'))    
        {
            $A.util.removeClass(component.find("claimDiv"), "slds-hide");
            $A.util.addClass(component.find("claimDiv"), "slds-show");            
            
            component.find("claimId").set("v.value","");
            var docType   =component.find("docType").get("v.value");
            var docTypeinputCmp = component.find("docType");   
            
            (docType === '' ||  docType === null || docType ===  undefined) ? docTypeinputCmp.setCustomValidity("Documnent Type is required"):docTypeinputCmp.setCustomValidity("");       
            docTypeinputCmp.reportValidity();            
            
        }else
        {     
            $A.util.removeClass(component.find("claimDiv"), "slds-show");
            $A.util.addClass(component.find("claimDiv"),"slds-hide" );
            
            component.find("claimId").set("v.value","");           
            var docType   =component.find("docType").get("v.value");
            var docTypeinputCmp = component.find("docType");             
            (docType === '' ||  docType === null || docType ===  undefined) ? docTypeinputCmp.setCustomValidity("Documnent Type is required"):docTypeinputCmp.setCustomValidity("");       
            docTypeinputCmp.reportValidity();            
        }
   
    },
    
    /*   Method for save Upload document*/
    save : function(component, event, helper) {
        
        
        var attchDate = component.find("attchDate").get("v.value");
        var attchNm   = component.find("attchNm").get("v.value");
        var docType   =component.find("docType").get("v.value");
        var claimId   =component.find("claimId").get("v.value");
        var direction =component.find("direct").get("v.value");
        
        
        
        var  validAttchDate = false;       
        var  validAttchNm = false;
        var  validDocType = false;
        var  validClaimId = false;
        var  validDirection= false;
        
        var attchDateinputCmp = component.find("attchDate");       
        var attchNminputCmp = component.find("attchNm"); 
        var docTypeinputCmp = component.find("docType"); 
        var claimIdinputCmp = component.find("claimId"); 
        var directioninputCmp = component.find("direct"); 
        if (attchDate === '' ||  attchDate === null||attchDate ===  undefined) 
        { 
            validAttchDate=false;
            attchDateinputCmp.setCustomValidity("Date and Time is required");
            attchDateinputCmp.reportValidity();
        }else{
            var currentDate = new Date();
            if(Date.parse(attchDate) > currentDate.getTime()){                
                validAttchDate=false;
                attchDateinputCmp.setCustomValidity("Please select today's date or past date. Future date is not allowed.");
                attchDateinputCmp.reportValidity();
            }else{
                validAttchDate=true;
                attchDateinputCmp.setCustomValidity("");
                attchDateinputCmp.reportValidity();
            }           
            
        }     
        
        if(attchNm === '' ||  attchNm === null||attchNm ===  undefined) 
        { 
            validAttchNm = false;
            attchNminputCmp.setCustomValidity("Attachment Name is required");
            attchNminputCmp.reportValidity();        
        }
        else{
            validAttchNm = true;
            attchNminputCmp.setCustomValidity(""); 
            attchNminputCmp.reportValidity();        
        }
        
        if(docType === '' ||  docType === null || docType ===  undefined)
        {  
            validDocType = false;
            docTypeinputCmp.setCustomValidity("Documnent Type is required");
            docTypeinputCmp.reportValidity(); 
        }else{ 
            
            validDocType = true;
            docTypeinputCmp.setCustomValidity("");       
            docTypeinputCmp.reportValidity();   
        }
        
        if((validDocType) && (docType.toLowerCase().includes('claim')) && (claimId === '' || claimId === undefined || claimId === null) ) 
        { 
            validClaimId = false;
            claimIdinputCmp.setCustomValidity("Enter 18 character Claim ID.");
            claimIdinputCmp.reportValidity();
        }
        else {
            if(claimId.length != 18)
            {
                validClaimId = false;
                claimIdinputCmp.setCustomValidity("Enter 18 character Claim ID.");
                claimIdinputCmp.reportValidity();
            }else{
                validClaimId = true;
                claimIdinputCmp.setCustomValidity("");          
                claimIdinputCmp.reportValidity();              
            }
        }
        if(direction === '' ||  direction === null || direction ===  undefined)
        {  
            validDirection = false;
            directioninputCmp.setCustomValidity("Direction is required");
            directioninputCmp.reportValidity(); 
        }else{ 
            
            validDirection = true;
            directioninputCmp.setCustomValidity("");       
            directioninputCmp.reportValidity();   
        }          
        
        if ( validAttchDate  && validAttchNm && validDocType && validDirection && (docType.toLowerCase().includes('claim')))
        {
            
            if(validClaimId)
            {
                
                if (component.find("fuploader").get("v.files") != null) { 
                    if(component.find("fuploader").get("v.files")[0]['name'].length <= 80 )
                    {
                        
                        helper.uploadHelper(component, event,helper);
                        
                    }else{
                        component.set("v.fileName", fileName);
                        component.set("v.fileErrorMesssage", "File Name should not excced 80 character with extension.");
                        return;	
                    }
                    
                } else {
                    
                    component.set("v.fileErrorMesssage", "Please select file to upload.");                      
                    return;
                }  
            }else{
                validClaimId = false;
                claimIdinputCmp.setCustomValidity("Enter 18 character Claim ID.");
                claimIdinputCmp.reportValidity();
                return;
            }
            
        }else if ( validAttchDate  && validAttchNm && validDocType && validDirection && (!(docType.toLowerCase().includes('claim'))))
        {
            
            if (component.find("fuploader").get("v.files") != null) { 
                if(component.find("fuploader").get("v.files")[0]['name'].length <= 80 )
                {
                    
                    helper.uploadHelper(component, event,helper);
                    
                }else{
                    component.set("v.fileName", fileName);
                    component.set("v.fileErrorMesssage", "File Name should not excced 80 character with extension.");
                    return;	
                }
                
            } else {
                
                component.set("v.fileErrorMesssage", "Please select file to upload.");                      
                return;
            }  
            
        }else{
            return;
            
        }      
        
    },
    
   /*   Method for File Upload validation*/ 
    handleFilesChange: function(component, event, helper) {
        var fileName = '';
        
        if (event.getSource().get("v.files").length > 0) {
            
            fileName = event.getSource().get("v.files")[0]['name'];
            if(fileName.length >80 )
            {
                component.set("v.fileName", fileName);
                component.set("v.fileErrorMesssage", "File Name should not excced 80 character with extension.");
                return;			
            }
        }
        component.set("v.fileName", fileName);
        component.set("v.fileErrorMesssage", ""); 
    },
    
   /*   Method to check Date Time Validation*/
    dateTimeUpdated: function(component,event,helper){
        var target = event.getSource();
        
        if(!$A.util.isUndefinedOrNull(target)) {
            var attchDateinputCmp = component.find("attchDate"); 
            var inputDateTimeValue = target.get("v.value");
            var currentDate = new Date();
            if(Date.parse(inputDateTimeValue) > currentDate.getTime()){               
                attchDateinputCmp.setCustomValidity("Please select today's date or past date. Future date is not allowed.");
                attchDateinputCmp.reportValidity();
            }else{
                attchDateinputCmp.setCustomValidity("");
                attchDateinputCmp.reportValidity();
            }
        }
    },
    
    /*For File Download*/
    startFileDownload : function(component, event, helper) {
        
        var selectedElement = event.target;
        var refId = selectedElement.getAttribute('data-refId');
        var docName = selectedElement.getAttribute('data-fileName');
        
        var action = component.get('c.downloadAttachment');
        action.setParams({
            'recordId' : component.get('v.recordId'),
            'storageRefId' : refId,
            'fileName' : docName
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if (state === "SUCCESS") {
            var result = response.getReturnValue();
            
            var downloadLink = document.createElement("a");
            downloadLink.href = result;
            downloadLink.download = docName;
            
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
            }
            else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                     if (errors[0] && errors[0].message) {
                    console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                     }
                }
            }
            
        });
        $A.enqueueAction(action);
        
    },
    /*File Download end*/
    
    
    /*
     * Method to get attached document List data table grid subtab
     * after click on View All
     */
    handleViewAllClick : function(component, event, helper){
        
        var recordId = component.get("v.recordId");
        helper.getAttachmentRelatedList(component);
       
        var medicaidOrNpiId = component.get("v.medicaidOrNpiId");
             
        var workspaceAPI = component.find("workspace");
        workspaceAPI.getEnclosingTabId().then(function(enclosingTabId) {
            workspaceAPI.openSubtab({
                parentTabId: enclosingTabId,
                pageReference: {
                    "type": "standard__component",
                    "attributes": {
                        "componentName": "c__OMMS_AttachmentDocumentListFilter"
                    },
                    "state": {
                        "uid": "1",
                        "c__recordId" : recordId,
                        "c__showSpinner" : 'true',
                        "c__isFromCase" : 'false'
                    }
                  }
            }).then(function(subtabId) {
                console.log("The new subtab ID is:" + subtabId);
                 console.log('component.get("v.medicaidOrNpiId")'+ medicaidOrNpiId);
                workspaceAPI.setTabLabel({
                    tabId: subtabId,
                    label: medicaidOrNpiId
                });
                workspaceAPI.setTabIcon({
                                    tabId: subtabId,
                                    icon: "standard:document",
                                    iconAlt: "Document List"
                        });
                workspaceAPI.focusTab({tabId : enclosingTabId});
				workspaceAPI.focusTab({tabId : subtabId}); 
            }).catch(function(error) {
                console.log("error");
            });
        });
        
    }
    /*View All end*/
    
})