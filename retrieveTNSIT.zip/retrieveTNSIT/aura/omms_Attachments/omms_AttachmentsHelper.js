({
    
    MAX_FILE_SIZE: 2500000, //Max file size 2.5 MB  
    
    /*
 * @Purpose :-
   Method:- To save attchment record to API
   Parameter:- 
   @Created Date: 27/04/2020
 */
    uploadHelper: function(component, event,helper) {
        
        component.set("v.showLoadingSpinner", true);
        component.set("v.isDisable", true); 
        var fileInput = component.find("fuploader").get("v.files");
        var fileName= component.find("fuploader").get("v.files")[0].name;
       
        try{
            var action = component.get('c.checkFileValidity');  
            var friendlyName=component.find("attchNm").get("v.value");
            action.setParams({
                friendlyNameAlreadyExists:component.get("v.docFileNames"),
                fileNameAlreadyExists:component.get("v.docFriendlyFileNames"),
                newFileName:fileName,
                newFriendlyName:friendlyName,
            });
            action.setCallback(this, function(response){
                var state = response.getState();        
                if (state === "SUCCESS") {                         
                    var resultString=response.getReturnValue();
                    if(resultString){
                        helper.showToast(component, event, helper, "Error","Error", resultString,"sticky");
                        component.set("v.showLoadingSpinner", false);
                        component.set("v.isDisable", false); 
                    }
                    else{
                        var file = fileInput[0];
                        var self = this;       
                        if (file.size > self.MAX_FILE_SIZE) {
                            component.set("v.showLoadingSpinner", false);
                            component.set("v.isDisable", false); 
                            component.set("v.fileErrorMesssage", 'Selected file size: ' + (file.size/1000000).toFixed(1) +'MB.\n' + ' File size cannot exceed ' + self.MAX_FILE_SIZE/1000000 +'MB');
                            return;
                        }
                        
                        // create a FileReader object 
                        var objFileReader = new FileReader();
                        // set onload function of FileReader object   
                        objFileReader.onload = $A.getCallback(function() {
                            var fileContents = objFileReader.result;
                            var base64 = 'base64,';
                            var dataStart = fileContents.indexOf(base64) + base64.length;
                            
                            fileContents = fileContents.substring(dataStart);
                            // call the uploadProcess method 
                            self.uploadProcess(component, file, fileContents);
                        });
                        
                        objFileReader.readAsDataURL(file); 
                        
                        
                    }
                }  else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log(errors[0].message);
                        }
                    }
                }
            });   
            $A.enqueueAction(action);  
        }
        catch(err) {
            console.log('err.message '+err.message);
        }
        
        
    },
    
    
    /*
 * @Purpose :-
   Method:- To Fetch attchment records from API
   Parameter:- Record Id of Object
   @Created Date: 27/04/2020
 */
    getAttachmentRelatedList: function(component) {
        /*fetch the attachment wrt the sobject on which the component is loaded*/
        component.set('v.isAttachmentNotAvailable', false);
        var getAttachmentAction = component.get('c.getAttachments');
        
        getAttachmentAction.setParams({
            'recordId' : component.get('v.recordId')
        });
        getAttachmentAction.setCallback(this, function(response){
            component.set("v.showSpinner", false);
            var state = response.getState();            
            if (state === "SUCCESS") {
                component.set('v.fetchedDocumentList', null);
                var docList = response.getReturnValue();
                
                component.set('v.fetchedAttachmentList', response.getReturnValue());    
                
                var docTypeSelectedByAdmin = component.get('v.docTypeForDesignAttribute');
                var docListOfTypeAsSelectedByAdmin = [];
                
                if(!docList || docList == ""){
                    component.set('v.isAttachmentNotAvailable', true);
                }
                
                if(docList){
                    var fileName=[];
                    var actualFileNames=[];
                    
                    var i;
                    for (i = 0; i < docList.length; i++) {
                        fileName.push(docList[i].documentName);
                        actualFileNames.push(docList[i].documentFileName );   
                    }
                    if(fileName){
                        component.set("v.docFileNames",fileName);
                    }
                    if(actualFileNames){
                        component.set("v.docFriendlyFileNames",actualFileNames);
                    }
                    if(docList.length > 3){
                        docList.splice(3,docList.length-3);	    
                    }                
                    component.set('v.fetchedDocumentList', docList);    
                }
            }
            else if (state === "ERROR") {
                component.set('v.fetchedDocumentList', null); 
                component.set('v.isAttachmentNotAvailable', true);
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                    }
                }
            }
            
        });       
        $A.enqueueAction(getAttachmentAction);
    },
    uploadProcess: function(component, file, fileContents) {       
        
        var action = component.get("c.saveUploadFile");
        
        action.setParams({
            recordId:component.get("v.recordId"),
            fileName:file.name,
            base64Data:encodeURIComponent(fileContents),
            documentType:component.find("docType").get("v.value"), 
            attachmentName:component.find("attchNm").get("v.value"), 
            direction:component.find("direct").get("v.value"),
            attachmentDateTime:component.find("attchDate").get("v.value"),
            claimId:component.find("claimId").get("v.value")           
            
        });
        // set call back 
        action.setCallback(this, function(response) {
            component.set("v.showLoadingSpinner", false);
            component.set("v.isDisable", false);
            var returnVal = response.getReturnValue();
            
            var state = response.getState();            
            if (state === "SUCCESS") {
                
                if(returnVal === null || returnVal === "")
                {
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "type": "ERROR",
                        "mode": "sticky",
                        "message": 'There is some processing error. Please contact System Administrator.'
                    });
                    toastEvent.fire();
                }
                else if(returnVal.statusCode == 0)
                { 
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title : "Success..",
                        message : "File has been uploaded successfully.",
                        type : 'success',
                    });
                    toastEvent.fire();  
                }  else{    
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "type": "ERROR",
                        "mode": "sticky",
                        "message": returnVal.errMessage
                    });
                    toastEvent.fire();
                }
                
                component.set("v.isOpen", false);
                
                component.set("v.fileName","");
                component.set("v.fileErrorMesssage","");                
                component.find("claimId").set("v.value","");
                // To refresh page and fetch new Attachments
                this.getAttachmentRelatedList(component);  
            } else if (state === "INCOMPLETE") {
                
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error",
                    "type": "ERROR",
                    "mode": "sticky",
                    "message": returnVal.errMessage
                });
                toastEvent.fire();
                component.set("v.isOpen", false);
                component.set("v.fileName","");
                component.set("v.fileErrorMesssage","");                
                component.find("claimId").set("v.value","");
                
            } else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                        var toastEvent = $A.get("e.force:showToast");
                        toastEvent.setParams({
                            "title": "Error",
                            "type": "ERROR",
                            "mode": "sticky",
                            "message": errors[0].message
                        });
                        toastEvent.fire();
                        
                        component.set("v.isOpen", false);
                        component.set("v.fileName","");
                        component.set("v.fileErrorMesssage","");                        
                        component.find("claimId").set("v.value","");
                    }
                } else {
                    
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        "title": "Error",
                        "type": "ERROR",
                        "mode": "sticky",
                        "message": returnVal.errMessage
                    });
                    toastEvent.fire();
                    component.set("v.isOpen", false);
                    component.set("v.fileName","");
                    component.set("v.fileErrorMesssage","");                    
                    component.find("claimId").set("v.value","");
                }
            }
        });
        // enqueue the action
        $A.enqueueAction(action);
    },
    
    /*
     * Method to get Medicaid and NPI Id for Member/Provider/Facility
     * wrt the sobject on which the component is loaded.
     */
    getMedicaidNPIId : function(component, helper) {
        var getMedicaidNpiIdAction = component.get('c.getMemberProviderDetails');     
        getMedicaidNpiIdAction.setParams({ 
            "recordId": component.get('v.recordId')			
        });       
        getMedicaidNpiIdAction.setCallback(this, $A.getCallback(function (response) {
            var state = response.getState();   
            if (state === "SUCCESS") {
                var response = response.getReturnValue() ;
                if(response != null){
                    if(response.developerName === 'MCO'){
                        console.log('response.taxId' +response.taxId);
                        component.set("v.medicaidOrNpiId", response.taxId);
                    }
                    if(response.developerName === 'PersonAccount'){
                        component.set("v.medicaidOrNpiId", response.medicaidId);
                    }
                    if(response.developerName === 'Atypical_Provider' || response.developerName === 'ommsCrmAtypical_Organization'){
                        component.set("v.medicaidOrNpiId", response.apiID);
                    }
                    if(response.developerName != 'PersonAccount' && response.developerName != 'Atypical_Provider' && response.developerName != 'ommsCrmAtypical_Organization' && response.developerName != 'MCO'){
                        component.set("v.medicaidOrNpiId", response.npiID);
                    }
                    if(response.developerName === 'Provider' || response.developerName === 'Provider_Contact'){
                        component.set("v.medicaidOrNpiId", response.provNpiID);
                    }  
                    
                    
                }
            }  else if (state === "ERROR") {
                
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log('OMMS-CRM-UM-AG-600000005 Server Call Exception:  '+errors[0].message);
                    }
                }
            }
        }));   
        $A.enqueueAction(getMedicaidNpiIdAction);
        
    },
    //Hide upload button on attachment component if current profile is State Agent (Read Only)
    getUserDetails: function(component, helper) {
        var actionUser = component.get('c.getUserInfo');       
        
        actionUser.setCallback(this, function(response){
            var state = response.getState();        
            if (state === "SUCCESS") {                         
                component.set("v.isReadOnlyProfile", response.getReturnValue());
            }  else if (state === "ERROR") {
                var errors = response.getError();
                if (errors) {
                    if (errors[0] && errors[0].message) {
                        console.log(errors[0].message);
                    }
                }
            }
        });   
        $A.enqueueAction(actionUser);    
    },
 /*   checkFileValidationsBeforeUploading:function(component, fileName) {
        debugger;
        try{
            var action = component.get('c.checkFileValidity');       
            action.setParams({
                friendlyNameAlreadyExists:component.get("v.docFileNames"),
                fileNameAlreadyExists:component.get("v.docFriendlyFileNames"),
                newFileName:fileName,
                newFriendlyName:component.find("attchNm").get("v.value"),
            });
            action.setCallback(this, function(response){
                var state = response.getState();        
                if (state === "SUCCESS") {                         
                    var resultString=response.getReturnValue();
                    if(resultString){
                        this.showToast(component, event, helper, 'Error','Error', resultString);
                        return false;
                    }
                    else{
                        return true;
                    }
                }  else if (state === "ERROR") {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log(errors[0].message);
                        }
                    }
                }
            });   
            $A.enqueueAction(action);  
        }
        catch(err) {
            console.log('err.message '+err.message);
        }
        
    },
   */ 
    showToast : function(component, event, helper, type, title, message,modeOfMessage) {
        var toastEvent = $A.get("e.force:showToast");
        toastEvent.setParams({
            "type":type,
            "title": title,
            "message": message,
            "mode": modeOfMessage
        });
        toastEvent.fire();
    },
    
})